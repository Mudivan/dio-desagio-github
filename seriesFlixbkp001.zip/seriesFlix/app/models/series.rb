class Series < ApplicationRecord
end
